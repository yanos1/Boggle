
JOKES_AND_FUN_FACTS = [
    "Why did the Boggle game go to the gym?\n To work on its 'board' strength",

    "Why did the Boggle game go to the beach?\n To catch some 'board' waves",

    "Boggle was invented by Allan Turoff in 1972,\n and later published by Parker Brothers in 1974.",

    "The game was first called 'Lexico' and later\n renamed to 'Boggle' by Turoff.",

    "The standard Boggle game set contains 16 letter cubes,\n with a letter on each of its six faces.",

    "The official Boggle world record for finding\n the most words in three minutes is 392 words.",

    "Boggle has been adapted into a variety of different\n languages and versions, including Boggle Junior,\n Super Boggle, and Big Boggle."]
